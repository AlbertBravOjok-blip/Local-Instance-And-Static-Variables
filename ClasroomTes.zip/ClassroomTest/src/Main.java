public class Main {

    static int cars = 10;

    static int boys = 20;

    public static void main(String[] args) {

        int age = 30;

        //int boys = 20;

        System.out.println("age is " + age);

        System.out.println("cars are " + cars);

        System.out.println("boys are " + boys);

    }
}
